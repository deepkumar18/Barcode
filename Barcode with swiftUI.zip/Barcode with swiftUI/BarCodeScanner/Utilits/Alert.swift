//
//  Alert.swift
//  BarCodeScanner
//
//  Created by Deep kumar  on 28/09/23.
//

import Foundation
import SwiftUI


struct AlertItem: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    let dismissButton: Alert.Button
}


struct AlertContext {
    static let invalidDeviceINput = AlertItem(title: "Invalid Device Input",
                                              message: "Something went wrong with camera.",
                                              dismissButton: .default(Text("OK")))
    static let invalidScannedType = AlertItem(title: "Invalid Scan Type",
                                              message: "The Value scanned is not valid.",
                                              dismissButton: .default(Text("OK")))
}
