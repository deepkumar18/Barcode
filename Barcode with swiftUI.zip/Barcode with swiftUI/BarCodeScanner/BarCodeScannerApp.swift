//
//  BarCodeScannerApp.swift
//  BarCodeScanner
//
//  Created by Deep kumar  on 24/09/23.
//

import SwiftUI

@main
struct BarCodeScannerApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            BarCodeScannerView()
        }
    }
}
